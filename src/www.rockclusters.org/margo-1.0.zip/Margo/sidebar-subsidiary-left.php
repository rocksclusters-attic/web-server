<?php global $theme; ?>

<div class="sidebar-subsidiary-left">

    <?php
        if(!dynamic_sidebar('sidebar_subsidiary_left')) {
            /**
            * The subsidiary left sidebar widget area. Manage the widgets from: wp-admin -> Appearance -> Widgets 
            */
            $theme->hook('sidebar_subsidiary_left');
        }
    ?>
    
</div><!-- .sidebar-subsidiary-left -->