
    </div><!-- #content-wrap -->
    
    <div id="primary-sidebar-wrap" class="span-8 last">
    
        <div id="primary-sidebar-wrap" class="span-8">
        
            <?php get_sidebars('primary'); ?>
    
        </div><!-- #primary-sidebar-wrap -->
        
        <div id="subsidiary-left-sidebar-wrap" class="span-4">
    
            <?php get_sidebars('subsidiary-left'); ?>
    
        </div><!-- #subsidiary-left-sidebar-wrap -->
        
        <div id="subsidiary-right-sidebar-wrap" class="span-4 last">
    
            <?php get_sidebars('subsidiary-right'); ?>
    
        </div><!-- #subsidiary-right-sidebar-wrap -->
    
    </div>
    
    
</div><!-- #main -->
        
<?php get_footer(); ?>