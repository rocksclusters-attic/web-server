<?php get_template_part('content', 'before'); ?>

    <div class="content">
    
        <?php get_template_part('loop', 'homepage'); ?> 
        
    </div><!-- .content -->

<?php get_template_part('content', 'after'); ?>