<?php global $theme; ?>

<div class="sidebar-subsidiary-right">

    <?php
        if(!dynamic_sidebar('sidebar_subsidiary_right')) {
            /**
            * The subsidiary right sidebar widget area. Manage the widgets from: wp-admin -> Appearance -> Widgets 
            */
            $theme->hook('sidebar_subsidiary_right');
        }
    ?>
    
</div><!-- .sidebar-subsidiary-right -->