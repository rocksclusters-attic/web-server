<?php global $theme; get_header(); ?>

    <div id="main" class="span-24">
    
        <div id="content-wrap" class="span-16">
        
        <?php $theme->hook('content_before'); ?>