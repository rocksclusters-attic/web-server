<?php get_template_part('content', 'before'); ?>

    <div class="content">
        
        <?php get_template_part('loop', 'page'); ?> 
        
    </div><!-- .content -->

<?php get_template_part('content', 'after'); ?>